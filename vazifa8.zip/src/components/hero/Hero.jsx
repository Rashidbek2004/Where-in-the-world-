import { IoIosSearch } from "react-icons/io";
import "./Hero.css";
const Hero = () => {
  return (
    <>
     
    </>
  );
};

export default Hero;
